#Nick Almeder
#New Student Stuff

#from graphics import *
import graphics
from tkinter import *
#import win32gui

root = Tk()

# def key(event):
#     root.event_generate('<Motion>', warp=True, x=50, y=50)

def motion(event):
    print('motion {}, {}'.format(event.x, event.y))

#root.bind('<Key>', key)
root.bind('<Motion>', motion)
#root.mainloop()


class BSUmapimage():
    #960x540
    #anchor point in direct center
    Map = graphics.GraphWin("BSU Campus", 1160,540)
    BSUimage = graphics.Image(graphics.Point(480,270), "BSU.gif")
    BSUimage.draw(Map)





#  ----------------Fix this later maybe I don't care-----------------------
def CH():

    CH = graphics.Rectangle(           #Crimson Hall
        graphics.Point(608,391),
        graphics.Point(550,338)

    )

    CH.setOutline("yellow")
    CH.draw(BSUmapimage.Map)

    #mousePos(self, CH)

def DH():
    DH = graphics.Rectangle(        #Dinardo Hall
        graphics.Point(615,318),
        graphics.Point(572,276)
    )

    DH.setOutline("Yellow")
    DH.draw(BSUmapimage.Map)

def WH():
    WH = graphics.Rectangle(        #Weygard Hall
        graphics.Point(672, 496),
        graphics.Point(612, 422)
    )

    WH.setOutline("Yellow")
    WH.draw(BSUmapimage.Map)

def ECC():
    ECC = graphics.Rectangle(       #East Campus Commons
        graphics.Point(671, 353),
        graphics.Point(628, 305)
    )

    ECC.setOutline("Yellow")
    ECC.draw(BSUmapimage.Map)

def SD():
    SD = graphics.Rectangle(          #SheaDurg
        graphics.Point(844,395),
        graphics.Point(791,322)
    )

    SD.setOutline("Yellow")
    SD.draw(BSUmapimage.Map)

def TC():
    TC = graphics.Rectangle(        #Tinsley Center
        graphics.Point(866,157),
        graphics.Point(813,84)
    )

    TC.setOutline("Yellow")
    TC.draw(BSUmapimage.Map)

def HART():
    Hart = graphics.Rectangle(      #Hart Hall
        graphics.Point(552,116),
        graphics.Point(509,78)
    )

    Hart.setOutline("Yellow")
    Hart.draw(BSUmapimage.Map)

def BURNELL():
    Burnell = graphics.Rectangle(       #Burnell Hall
        graphics.Point(637,80),
        graphics.Point(569,9)
    )

    Burnell.setOutline("Yellow")
    Burnell.draw(BSUmapimage.Map)

def KG():
    KG = graphics.Rectangle(           #Kelly Gymnasium
        graphics.Point(296,276),
        graphics.Point(243,223)
    )

    KG.setOutline("Yellow")
    KG.draw(BSUmapimage.Map)

def ML():
    ML = graphics.Rectangle(        #Maxwell Library
        graphics.Point(242,329),
        graphics.Point(189,276)
    )

    ML.setOutline("Yellow")
    ML.draw(BSUmapimage.Map)

def DMF():
    DMF = graphics.Rectangle(       #Dana Mohler Ferriah
        graphics.Point(278,202),
        graphics.Point(202,167)
    )

    DMF.setOutline("Yellow")
    DMF.draw(BSUmapimage.Map)

def RCC():
    RCC = graphics.Rectangle(        #Rondilieu Campus Center
        graphics.Point(167,280),
        graphics.Point(86,214)
    )

    RCC.setOutline("Yellow")
    RCC.draw(BSUmapimage.Map)

def SH():
    SH = graphics.Rectangle(        #Scott Hall
        graphics.Point(107,359),
        graphics.Point(77,300)
    )

    SH.setOutline("Yellow")
    SH.draw(BSUmapimage.Map)

def WWH_HaH():
    WWH_HaH = graphics.Rectangle(   #Woodward Hall and Harrington Hall
        graphics.Point(31,412),
        graphics.Point(0,318)
    )

    WWH_HaH.setOutline("Yellow")
    WWH_HaH.draw(BSUmapimage.Map)

def THH():
    THH = graphics.Rectangle(       #Hunt Hall
        graphics.Point(57,261),
        graphics.Point(0,211)
    )

    THH.setOutline("Yellow")
    THH.draw(BSUmapimage.Map)

def AC():
    AC = graphics.Rectangle(        #Art Center
        graphics.Point(40,185),
        graphics.Point(5,154)
    )

    AC.setOutline("Yellow")
    AC.draw(BSUmapimage.Map)

def MH():
    MH = graphics.Rectangle(        #MIles Hall
        graphics.Point(640,279),
        graphics.Point(599,248)
    )

    MH.setOutline("Yellow")
    MH.draw(BSUmapimage.Map)

def MC():
    MC = graphics.Rectangle(        #Moakley Center
        graphics.Point(547,154),
        graphics.Point(506,123)
    )

    MC.setOutline("Yellow")
    MC.draw(BSUmapimage.Map)
def PH():
    PH = graphics.Rectangle(
        graphics.Point(134,174),
        graphics.Point(83, 122)
    )

    PH.setOutline("Yellow")
    PH.draw(BSUmapimage.Map)

#--------------------------------------------------------------------------

class Filter():
    Legend = graphics.Rectangle(
        graphics.Point(344,529),
        graphics.Point(14,421)
    )
    Legend.setFill("White")
    Legend.setOutline("Black")
    Legend.draw(BSUmapimage.Map)




def main():
    BSUmapimage()
    CH()
    DH()
    HART()
    BURNELL()
    KG()
    ML()
    DMF()
    RCC()
    SH()
    WWH_HaH()
    THH()
    AC()
    MH()
    MC()
    PH()
    TC()
    SD()
    WH()
    ECC()

    BSUmapimage.Map.getMouse()
    BSUmapimage.Map.close()




main()